"""Apply MATCHDAY99_v08_to_v09.bps using Python 3, without external packages."""
from pathlib import Path
import sys,json,hashlib,zlib,struct,shutil

def apply(source,patch):
    if patch[:4]!=b'BPS1':raise ValueError('Not a BPS patch')
    source_crc,target_crc,patch_crc=struct.unpack('<III',patch[-12:])
    if zlib.crc32(patch[:-4])!=patch_crc:raise ValueError('Patch CRC mismatch')
    if zlib.crc32(source)!=source_crc:raise ValueError('Source CRC mismatch: use the exact v0.8 Track 01')
    pos=4
    def integer():
        nonlocal pos
        value=0;shift=1
        while True:
            if pos>=len(patch)-12:raise ValueError('Truncated patch')
            x=patch[pos];pos+=1;value+=(x&127)*shift
            if x&128:return value
            shift<<=7;value+=shift
    source_size=integer();target_size=integer();metadata_size=integer();pos+=metadata_size
    if source_size!=len(source):raise ValueError('Source size mismatch')
    out=bytearray();source_relative=target_relative=0
    while len(out)<target_size:
        action=integer();mode=action&3;length=(action>>2)+1
        if len(out)+length>target_size:raise ValueError('Invalid output length')
        if mode==0:
            start=len(out);out.extend(source[start:start+length])
        elif mode==1:
            if pos+length>len(patch)-12:raise ValueError('Truncated literal data')
            out.extend(patch[pos:pos+length]);pos+=length
        else:
            delta=integer();delta=-(delta>>1) if delta&1 else delta>>1
            if mode==2:
                source_relative+=delta
                if not 0<=source_relative<=len(source)-length:raise ValueError('Invalid source copy')
                out.extend(source[source_relative:source_relative+length]);source_relative+=length
            else:
                target_relative+=delta
                if not 0<=target_relative<len(out):raise ValueError('Invalid target copy')
                for _ in range(length):out.append(out[target_relative]);target_relative+=1
    if pos!=len(patch)-12 or zlib.crc32(out)!=target_crc:raise ValueError('Output CRC mismatch')
    return out

def main():
    here=Path(__file__).resolve().parent
    if len(sys.argv)<2:
        print('Usage: python apply_v09.py "path/to/extracted_v08_folder" [new_output_folder]')
        return 1
    source_dir=Path(sys.argv[1]).expanduser().resolve()
    if source_dir.is_file():source_dir=source_dir.parent
    output=Path(sys.argv[2]).expanduser().resolve() if len(sys.argv)>2 else source_dir.parent/'MATCHDAY99_v09'
    if output.exists() and any(output.iterdir()):raise ValueError('Output folder must be empty; originals will not be overwritten')
    manifest=json.loads((here/'manifest.json').read_text())
    source_path=source_dir/'ISS Pro Evolution (Track 01) - MATCHDAY99_v08.bin'
    source=source_path.read_bytes()
    if hashlib.sha256(source).hexdigest()!=manifest['source_sha256']:raise ValueError('Wrong source SHA-256; use the Release v1.0.0 v0.8 file')
    for track in manifest['audio_tracks']:
        path=source_dir/track['file']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=track['sha256']:raise ValueError('Missing or changed audio track: '+track['file'])
    patch=(here/'MATCHDAY99_v08_to_v09.bps').read_bytes()
    if hashlib.sha256(patch).hexdigest()!=manifest['patch_sha256']:raise ValueError('Patch SHA-256 mismatch')
    target=apply(source,patch)
    if hashlib.sha256(target).hexdigest()!=manifest['target_sha256']:raise ValueError('Output SHA-256 mismatch')
    cue=(source_dir/'ISS Pro Evolution - MATCHDAY99_v08.cue').read_bytes()
    old=b'ISS Pro Evolution (Track 01) - MATCHDAY99_v08.bin'
    if old not in cue:raise ValueError('Unexpected original CUE')
    output.mkdir(parents=True,exist_ok=True)
    (output/'ISS Pro Evolution (Track 01) - MATCHDAY99_v09.bin').write_bytes(target)
    (output/'ISS Pro Evolution - MATCHDAY99_v09.cue').write_bytes(cue.replace(old,b'ISS Pro Evolution (Track 01) - MATCHDAY99_v09.bin'))
    for track in manifest['audio_tracks']:shutil.copy2(source_dir/track['file'],output/track['file'])
    print('Verified v0.9 BIN/CUE and 11 unchanged audio tracks written to:',output)
    print('Open ISS Pro Evolution - MATCHDAY99_v09.cue in your emulator. Original v0.8 files were preserved.')
    return 0
if __name__=='__main__':
    try:sys.exit(main())
    except (OSError,ValueError,KeyError) as e:
        print('ERROR:',e,file=sys.stderr);sys.exit(2)
